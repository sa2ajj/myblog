#! /usr/bin/python

__copyright__ = 'Copyright (C) 2005, Mikhail Sobolev <mss@mawhrin.net>'

import sys, os
import re
import types

def format_header(what):
  if what == 'groups':
    r = '[groups]'
  elif what[0] is None:
    r = '[%s]' % what[1]
  else:
    r = '[%s:%s]' % what

  return r

_header = re.compile(r'^\[((?P<groups>groups)|((?P<repo>[^:]+):)?(?P<path>/.*))\]$')

class AuthZFile:
  def __init__(self, fname):
    self.fname = fname
    self.groups = None
    self.sections = {}

  def read(self, fp = None):
    if fp is not None:
      f = fp
    else:
      f = open(self.fname, 'r')

    current = None
    lines = []

    for line in f.readlines():
      line = line.strip()

      m = _header.match(line)

      if m:
        if current is not None:
          section = '\n'.join(lines)

          if current == 'groups':
            self.groups = section
          else:
            self.sections[current] = section

        if m.group('groups') is not None:
          current = 'groups'
        else:
          current = m.group('repo'), m.group('path')

        lines = []
      else:
        if current is not None:
          lines.append(line)

    if current is not None:
      section = '\n'.join(lines)

      if current == 'groups':
        self.groups = section
      else:
        self.sections[current] = section

    if fp is None:
      f.close()

  def write(self, name = None):
    if name is None:
      outname = self.fname+'.new'
    else:
      outname = name

    f = open(outname,'w')

    if self.groups is not None:
      print >> f, '[groups]'
      print >> f, self.groups

    def cmp_repos(x,y):
      r = cmp(x[0], y[0])

      if r == 0:
        r = cmp(x[1], y[1])

      return r

    keys = self.sections.keys()
    keys.sort(cmp_repos)

    for key in keys:
      print >> f, format_header(key)
      print >> f, self.sections[key]

    f.close()

    if name is None:
      os.unlink(self.fname)
      os.rename(outname, self.fname)

  def keys(self):
    return self.sections.keys()

  def __contains__(self, key):
    if key == 'groups':
      r = self.groups is not None
    else:
      r = key in self.sections

    return r

  def __getitem__(self, key):
    if key == 'groups':
      result = self.groups
    else:
      assert type(key) == types.TupleType and len(key) == 2, 'Key must be a tuple that specifies repository and path'

      result = self.sections.get(key, None)

    return result

  def __setitem__(self, key, value):
    assert type(value) == types.StringType, 'The value must be a string'

    if key == 'groups':
      self.groups = value
    else:
      assert type(key) == types.TupleType and len(key) == 2, 'Key must be a tuple that specifies repository and path'

      self.sections[key] = value

  def __delitem__(self, key):
    if key == 'groups':
      self.groups = None
    else:
      assert type(key) == types.TupleType and len(key) == 2, 'Key must be a tuple that specifies repository and path'

      if key in self.sections:    # this version is more relaxed: we allow deletion of non-existant keys
        del self.sections[key]

  def repo_keys(self, repo):
    if repo == '':
      repo = None

    return filter(lambda x, r = repo : x[0] == r, self.keys())
