#! /usr/bin/python

from distutils.core import setup

setup (
        name='authz-tools',
        version = '0.4',
        description='a set of tools for working with authz files',
        long_description='''\
This package contains a module for "manipulating" AuthZ files and a set of
tools that allow extracting, replacing and deleting information about a
particular repository''',
        author='Mikhail Sobolev',
        author_email = 'mss@mawhrin.net',
        py_modules = [ 'AuthZFile' ],
        scripts = [ 'authz-tool', 'authz-admin' ],
        url = 'http://only.mawhrin.net/~mss/thingies/authz/',
        classifiers = [
            'Development Status :: 4 - Beta',
            'Programming Language :: Python',
            'Intended Audience :: Developers',
            'Intended Audience :: System Administrators',
            'Environment :: Console',
            'License :: OSI Approved :: GNU General Public License (GPL)',
            'Operating System :: OS Independent',
        ],
        license = 'GPL v2',
        platforms = 'win32,posix'
)
