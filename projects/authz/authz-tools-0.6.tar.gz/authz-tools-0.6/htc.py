#! /usr/bin/python

import sys
from random import randint
from crypt import crypt
from getpass import getpass
import string

from HTPFile import HTPasswdFile

file = 'some.passwd'

hpf = HTPasswdFile(file)
hpf.read()

sys.stdout.write('Enter UID: ')
user = sys.stdin.readline()
pwd = getpass('Enter password: ')

user = user.strip()

print 'checking:', hpf.check(user, pwd)
