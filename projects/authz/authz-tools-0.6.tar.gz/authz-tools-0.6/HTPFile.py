#

import os
from random import randint
from crypt import crypt
import string

symbols = './' + string.lowercase + string.uppercase + string.digits

class HTPasswdFile:
  def __init__ (self, fname):
    self.__fname = fname
    self.__index = {}
    self.__users = []

  def read(self):
    f = open(self.__fname, 'r')

    self.__index = {}
    self.__users = []

    for line in f.readlines():
      line = line.strip()

      parts = line.split(':')

      self.__index[parts[0]] = len(self.__users)
      self.__users.append(parts)

    f.close()

  def write(self):
    outname = self.__fname + '.new'

    f = open(outname, 'w')

    for record in self.__users:
      print >> f, ':'.join(record)

    f.close()

    os.unlink(self.__fname)
    os.rename(outname, self.__fname)

  def users(self):
    return self.__index.keys()

  def add(self, user, password):
    if user not in self.__index:
      self.__index[user] = len(self.__users)
      self.users.append ([user, ''])

      self.set(user, password)

  def check(self, user, password):
    if user in self.__index:
      crypted = self.__users[self.__index[user]][1]

      result = crypt(password, crypted) == crypted
    else:
      result = False

    return result

  def set(self, user, password):
    if user in self.__index:
      salt = randint(0,4095)

      s1, s2 = salt / 64, salt % 64

      crypted = crypt(p1, symbols[s1]+symbols[s2])

      self.__users[self.__index[user]][1] = crypted
    else:
      pass  # simply ignore!

  def disable(self, user):
    pass

  def enable(self, user):
    pass
